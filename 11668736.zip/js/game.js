const UPGRADES = [
  { id: 'finger', icon: '👆', type: 'click', base: 1, power: 1, costBase: 15, costMult: 1.15 },
  { id: 'glove', icon: '🧤', type: 'click', base: 1, power: 3, costBase: 80, costMult: 1.18 },
  { id: 'brain', icon: '🧠', type: 'click', base: 1, power: 8, costBase: 400, costMult: 1.2 },
  { id: 'bot', icon: '🤖', type: 'auto', base: 1, power: 2, costBase: 50, costMult: 1.16 },
  { id: 'factory', icon: '🏭', type: 'auto', base: 1, power: 12, costBase: 350, costMult: 1.19 },
  { id: 'mult', icon: '✨', type: 'mult', base: 1, power: 1.5, costBase: 2000, costMult: 2.5, maxLevel: 10 },
];

const ACHIEVEMENTS = [
  { id: 'first', icon: '🎯', check: (s) => s.totalClicks >= 1 },
  { id: '100', icon: '💯', check: (s) => s.totalClicks >= 100 },
  { id: '1k', icon: '⭐', check: (s) => s.score >= 1000 },
  { id: '67k', icon: '🔥', check: (s) => s.score >= 67000 },
  { id: '1m', icon: '👑', check: (s) => s.score >= 1000000 },
  { id: 'max', icon: '🏆', check: (s) => UPGRADES.every((u) => (s.levels[u.id] || 0) >= 50) },
];

const Game = (() => {
  const state = {
    score: 0,
    totalClicks: 0,
    levels: {},
    unlockedAch: {},
    soundOn: true,
    lastSave: 0,
  };

  let clickPower = 1;
  let autoPerSec = 0;
  let multiplier = 1;
  let boostUntil = 0;
  let lastTick = performance.now();
  let saveDebounce = null;
  let lastInterstitial = 0;
  let upgradeEls = {};

  const $ = (id) => document.getElementById(id);

  function formatNum(n) {
    if (n >= 1e12) return (n / 1e12).toFixed(2) + 'T';
    if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
    if (n >= 1e4) return (n / 1e3).toFixed(1) + 'K';
    if (n >= 1000) return Math.floor(n).toLocaleString(currentLang === 'ru' ? 'ru-RU' : 'en-US');
    return Math.floor(n).toString();
  }

  function getUpgradeCost(up, level) {
    return Math.floor(up.costBase * Math.pow(up.costMult, level));
  }

  function recalcStats() {
    clickPower = 1;
    autoPerSec = 0;
    multiplier = 1;

    UPGRADES.forEach((up) => {
      const lv = state.levels[up.id] || 0;
      if (!lv) return;
      if (up.type === 'click') clickPower += up.power * lv;
      if (up.type === 'auto') autoPerSec += up.power * lv;
      if (up.type === 'mult') multiplier *= Math.pow(up.power, lv);
    });
  }

  function getClickGain() {
    let gain = clickPower * multiplier;
    if (Date.now() < boostUntil) gain *= 2;
    return Math.max(1, Math.floor(gain));
  }

  function getAutoGain() {
    let gain = autoPerSec * multiplier;
    if (Date.now() < boostUntil) gain *= 2;
    return gain;
  }

  function playClickSound() {
    if (!state.soundOn) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 440 + Math.random() * 120;
      osc.type = 'sine';
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.08);
    } catch (_) { /* no audio */ }
  }

  function spawnFloat(x, y, text) {
    const container = $('float-container');
    const el = document.createElement('span');
    el.className = 'float-text';
    el.textContent = '+' + text;
    const rect = container.getBoundingClientRect();
    el.style.left = (x - rect.left) + 'px';
    el.style.top = (y - rect.top) + 'px';
    container.appendChild(el);
    setTimeout(() => el.remove(), 800);
  }

  function doClick(ev) {
    if (SdkBridge.isPaused()) return;

    const gain = getClickGain();
    state.score += gain;
    state.totalClicks += 1;

    const btn = $('btn-click');
    btn.classList.add('pressed');
    setTimeout(() => btn.classList.remove('pressed'), 100);

    if (ev) {
      const x = ev.clientX ?? ev.touches?.[0]?.clientX ?? 0;
      const y = ev.clientY ?? ev.touches?.[0]?.clientY ?? 0;
      spawnFloat(x, y, formatNum(gain));
    }

    playClickSound();
    checkAchievements();
    updateUI();
    scheduleSave();
  }

  function buyUpgrade(id) {
    const up = UPGRADES.find((u) => u.id === id);
    if (!up) return;

    const lv = state.levels[id] || 0;
    if (up.maxLevel && lv >= up.maxLevel) return;

    const cost = getUpgradeCost(up, lv);
    if (state.score < cost) return;

    state.score -= cost;
    state.levels[id] = lv + 1;
    recalcStats();
    checkAchievements();
    updateUI();
    scheduleSave();
  }

  function checkAchievements() {
    let changed = false;
    ACHIEVEMENTS.forEach((ach) => {
      if (state.unlockedAch[ach.id]) return;
      if (ach.check(state)) {
        state.unlockedAch[ach.id] = true;
        changed = true;
      }
    });
    if (changed) renderAchievements();
  }

  function scheduleSave() {
    clearTimeout(saveDebounce);
    saveDebounce = setTimeout(() => saveGame(false), 3000);
  }

  async function saveGame(manual) {
    const ok = await SdkBridge.saveProgress({
      score: state.score,
      totalClicks: state.totalClicks,
      levels: state.levels,
      unlockedAch: state.unlockedAch,
      soundOn: state.soundOn,
    });

    if (manual) {
      SdkBridge.submitScore(state.score);
    }

    const status = $('save-status');
    if (manual) {
      status.textContent = ok ? t('saved') : t('saveError');
      status.className = 'save-status' + (ok ? ' saved' : '');
      setTimeout(() => { status.textContent = ''; }, 2000);
    }
  }

  async function renderLeaderboard() {
    const list = $('leaderboard-list');
    const msg = $('leaderboard-msg');
    const loginBtn = $('btn-leaderboard-login');
    list.innerHTML = '';
    loginBtn.classList.add('hidden');

    if (!SdkBridge.hasLeaderboards()) {
      msg.textContent = t('lbLocalOnly');
      return;
    }

    msg.textContent = t('lbLoading');
    await SdkBridge.submitScore(state.score);
    const res = await SdkBridge.getLeaderboardEntries();

    if (!res) {
      msg.textContent = t('lbNeedAuth');
      loginBtn.classList.remove('hidden');
      return;
    }

    const entries = res.entries || [];
    if (!entries.length) {
      msg.textContent = t('lbEmpty');
      return;
    }

    msg.textContent = '';
    entries.forEach((entry) => {
      const isYou = entry.rank === res.userRank;
      const li = document.createElement('li');
      li.className = 'leaderboard-item' + (isYou ? ' is-you' : '');

      let avatar = '';
      try {
        const src = entry.player?.getAvatarSrc?.('small');
        if (src) avatar = `<img class="lb-avatar" src="${src}" alt="">`;
      } catch (_) { /* no avatar */ }

      const rawName = entry.player?.publicName;
      const name = isYou ? t('lbYou') : (rawName && rawName.length ? rawName : t('lbAnon'));
      const score = entry.formattedScore || formatNum(entry.score);

      li.innerHTML = `
        <span class="lb-rank">${entry.rank}</span>
        ${avatar || '<span class="lb-avatar"></span>'}
        <span class="lb-name"></span>
        <span class="lb-score">${score}</span>
      `;
      li.querySelector('.lb-name').textContent = name;
      list.appendChild(li);
    });
  }

  function buildUpgrades() {
    const list = $('upgrades-list');
    list.innerHTML = '';
    upgradeEls = {};

    UPGRADES.forEach((up) => {
      const li = document.createElement('li');
      li.className = 'upgrade-item locked';
      li.innerHTML = `
        <div class="upgrade-icon">${up.icon}</div>
        <div class="upgrade-info">
          <div class="upgrade-name">${t('upgrade_' + up.id)}</div>
          <div class="upgrade-desc">${t('upgrade_' + up.id + '_desc')}</div>
        </div>
        <div class="upgrade-meta">
          <div class="upgrade-cost"></div>
          <div class="upgrade-level"></div>
        </div>
      `;
      li.addEventListener('click', () => buyUpgrade(up.id));
      list.appendChild(li);
      upgradeEls[up.id] = {
        li,
        cost: li.querySelector('.upgrade-cost'),
        level: li.querySelector('.upgrade-level'),
      };
    });

    refreshUpgrades();
  }

  function refreshUpgrades() {
    UPGRADES.forEach((up) => {
      const els = upgradeEls[up.id];
      if (!els) return;
      const lv = state.levels[up.id] || 0;
      const maxed = up.maxLevel && lv >= up.maxLevel;
      const cost = getUpgradeCost(up, lv);
      const canBuy = !maxed && state.score >= cost;
      els.li.className = 'upgrade-item' + (canBuy ? ' can-buy' : ' locked');
      els.cost.textContent = maxed ? 'MAX' : formatNum(cost);
      els.level.textContent = `${t('level')} ${lv}${up.maxLevel ? '/' + up.maxLevel : ''}`;
    });
  }

  function renderAchievements() {
    const list = $('achievements-list');
    list.innerHTML = '';

    ACHIEVEMENTS.forEach((ach) => {
      const unlocked = !!state.unlockedAch[ach.id];
      const li = document.createElement('li');
      li.className = 'achievement-item' + (unlocked ? ' unlocked' : '');
      li.innerHTML = `
        <span class="badge">${ach.icon}</span>
        <div class="upgrade-info">
          <div class="upgrade-name">${t('ach_' + ach.id)}</div>
          <div class="upgrade-desc">${t('ach_' + ach.id + '_desc')}</div>
        </div>
      `;
      list.appendChild(li);
    });
  }

  function updateUI() {
    $('score').textContent = formatNum(state.score);
    $('per-sec').textContent = formatNum(getAutoGain());
    $('total-clicks').textContent = formatNum(state.totalClicks);

    const boostEl = $('boost-indicator');
    if (Date.now() < boostUntil) {
      boostEl.classList.remove('hidden');
    } else {
      boostEl.classList.add('hidden');
    }

    refreshUpgrades();
  }

  function gameLoop(now) {
    if (!SdkBridge.isPaused()) {
      const dt = Math.min((now - lastTick) / 1000, 0.5);
      lastTick = now;

      const auto = getAutoGain();
      if (auto > 0 && dt > 0) {
        state.score += auto * dt;
        checkAchievements();
      }
    } else {
      lastTick = now;
    }

    updateUI();
    requestAnimationFrame(gameLoop);
  }

  function activateBoost() {
    SdkBridge.showRewarded(() => {
      boostUntil = Date.now() + 30000;
      $('btn-reward').disabled = true;
      setTimeout(() => {
        $('btn-reward').disabled = false;
      }, 30000);
    });
  }

  // Interstitial ads are only shown at logical pauses (switching away from the
  // click screen to browse a tab), never during active real-time gameplay, and
  // are throttled by a client-side cooldown (п. 4.4 требований платформы).
  function maybeShowInterstitial() {
    if (Date.now() - lastInterstitial < 180000) return;
    if (state.score < 500) return;
    lastInterstitial = Date.now();
    SdkBridge.showFullscreen(() => {});
  }

  function setupTabs() {
    document.querySelectorAll('.tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        const id = tab.dataset.tab;
        const alreadyActive = tab.classList.contains('active');

        document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
        document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
        tab.classList.add('active');
        $('panel-' + id).classList.add('active');

        if (alreadyActive) return;

        if (id === 'leaderboard') {
          renderLeaderboard();
        } else {
          maybeShowInterstitial();
        }
      });
    });
  }

  function applySave(data) {
    if (!data) return;
    state.score = data.score || 0;
    state.totalClicks = data.totalClicks || 0;
    state.levels = data.levels || {};
    state.unlockedAch = data.unlockedAch || {};
    state.soundOn = data.soundOn !== false;
    recalcStats();
  }

  function onPause() {
    saveGame(false);
  }

  function onResume() {
    lastTick = performance.now();
  }

  async function start() {
    $('loader-text').textContent = t('loading');

    const saved = await SdkBridge.init();
    applySave(saved);

    $('loader').classList.add('hidden');
    $('app').classList.remove('hidden');
    SdkBridge.signalReady();
    SdkBridge.gameplayStart();

    applyI18n();
    buildUpgrades();
    renderAchievements();
    updateUI();
    setupTabs();
    setupInputGuards();
    setAppHeight();

    let lastPointer = 0;
    $('btn-click').addEventListener('pointerdown', (e) => {
      e.preventDefault();
      const now = Date.now();
      if (now - lastPointer < 80) return;
      lastPointer = now;
      doClick(e);
    });

    $('btn-reward').addEventListener('click', activateBoost);
    $('btn-save').addEventListener('click', () => saveGame(true));

    $('btn-leaderboard-login').addEventListener('click', async () => {
      const ok = await SdkBridge.requestAuth();
      if (ok) renderLeaderboard();
    });

    $('btn-sound').addEventListener('click', () => {
      state.soundOn = !state.soundOn;
      $('btn-sound').textContent = state.soundOn ? '🔊' : '🔇';
      scheduleSave();
    });
    $('btn-sound').textContent = state.soundOn ? '🔊' : '🔇';

    lastTick = performance.now();
    requestAnimationFrame(gameLoop);

    setInterval(() => saveGame(false), 60000);
  }

  // Lock the page so the game behaves like a native app inside the Yandex frame:
  // no text selection, no context menu / long-press callout, no pinch-zoom and
  // no browser scroll / pull-to-refresh (пп. 1.6.1.8, 1.6.2.7, 1.10.2).
  function setupInputGuards() {
    const block = (e) => e.preventDefault();
    document.addEventListener('contextmenu', block);
    document.addEventListener('selectstart', block);
    document.addEventListener('dragstart', block);
    document.addEventListener('gesturestart', block);

    document.addEventListener('touchmove', (e) => {
      if (e.touches.length > 1) {
        e.preventDefault();
        return;
      }
      if (!e.target.closest('.panel')) {
        e.preventDefault();
      }
    }, { passive: false });
  }

  function setAppHeight() {
    document.documentElement.style.setProperty('--app-height', window.innerHeight + 'px');
  }

  window.addEventListener('resize', setAppHeight);
  window.addEventListener('orientationchange', setAppHeight);

  return { start, onPause, onResume };
})();

document.addEventListener('DOMContentLoaded', () => Game.start());
