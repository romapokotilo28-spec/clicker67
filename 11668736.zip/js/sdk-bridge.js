const SdkBridge = (() => {
  let ysdk = null;
  let player = null;
  let leaderboards = null;
  let paused = false;

  const STORAGE_KEY = 'clicker67_save';
  const LEADERBOARD_NAME = 'score';

  async function init() {
    try {
      if (typeof YaGames !== 'undefined') {
        ysdk = await YaGames.init();
        const lang = ysdk.environment?.i18n?.lang;
        if (lang) setLanguage(lang);

        try {
          player = await ysdk.getPlayer();
        } catch (e) {
          console.warn('Player init:', e);
        }

        try {
          leaderboards = await ysdk.getLeaderboards();
        } catch (e) {
          console.warn('Leaderboards init:', e);
        }

      } else {
        console.info('SDK not found — local mode');
        setLanguage(navigator.language);
      }
    } catch (e) {
      console.warn('SDK init failed:', e);
      setLanguage(navigator.language);
    }

    document.addEventListener('visibilitychange', () => {
      paused = document.hidden;
      if (paused) {
        gameplayStop();
        if (typeof Game !== 'undefined') Game.onPause();
      } else {
        gameplayStart();
        if (typeof Game !== 'undefined') Game.onResume();
      }
    });

    return loadProgress();
  }

  function isPaused() {
    return paused;
  }

  async function loadProgress() {
    let data = null;

    if (player) {
      try {
        data = await player.getData();
        if (data && Object.keys(data).length) return data;
      } catch (e) {
        console.warn('Cloud load:', e);
      }
    }

    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn('Local load:', e);
    }

    return null;
  }

  async function saveProgress(state) {
    const payload = { ...state, savedAt: Date.now() };

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (e) {
      console.warn('Local save:', e);
    }

    if (player) {
      try {
        await player.setData(payload, true);
        return true;
      } catch (e) {
        console.warn('Cloud save:', e);
        return false;
      }
    }

    return true;
  }

  function signalReady() {
    ysdk?.features?.LoadingAPI?.ready?.();
  }

  function gameplayStart() {
    ysdk?.features?.GameplayAPI?.start?.();
  }

  function gameplayStop() {
    ysdk?.features?.GameplayAPI?.stop?.();
  }

  function showRewarded(onReward) {
    if (!ysdk?.adv?.showRewardedVideo) {
      if (onReward) onReward();
      return;
    }

    if (!onReward) return;

    let rewarded = false;
    gameplayStop();
    ysdk.adv.showRewardedVideo({
      callbacks: {
        onOpen: () => gameplayStop(),
        onRewarded: () => {
          rewarded = true;
          if (onReward) onReward();
        },
        onClose: () => {
          gameplayStart();
        },
        onError: () => {
          gameplayStart();
        },
      },
    });
  }

  function hasLeaderboards() {
    return !!leaderboards;
  }

  async function submitScore(score) {
    if (!leaderboards) return false;
    try {
      await leaderboards.setLeaderboardScore(LEADERBOARD_NAME, Math.floor(score));
      return true;
    } catch (e) {
      console.warn('Leaderboard submit:', e);
      return false;
    }
  }

  async function getLeaderboardEntries() {
    if (!leaderboards) return null;
    try {
      const res = await leaderboards.getLeaderboardEntries(LEADERBOARD_NAME, {
        quantityTop: 10,
        includeUser: true,
        quantityAround: 5,
      });
      return res || { entries: [] };
    } catch (e) {
      console.warn('Leaderboard load:', e);
      return null;
    }
  }

  async function requestAuth() {
    if (!ysdk?.auth?.openAuthDialog) return false;
    try {
      await ysdk.auth.openAuthDialog();
      player = await ysdk.getPlayer();
      return true;
    } catch (e) {
      console.warn('Auth:', e);
      return false;
    }
  }

  function showFullscreen(onClose) {
    if (!ysdk?.adv?.showFullscreenAdv) {
      if (onClose) onClose(false);
      return;
    }

    gameplayStop();
    ysdk.adv.showFullscreenAdv({
      callbacks: {
        onOpen: () => gameplayStop(),
        onClose: (wasShown) => {
          gameplayStart();
          if (onClose) onClose(wasShown);
        },
        onError: () => {
          gameplayStart();
          if (onClose) onClose(false);
        },
      },
    });
  }

  return {
    init,
    signalReady,
    gameplayStart,
    isPaused,
    saveProgress,
    showRewarded,
    showFullscreen,
    hasLeaderboards,
    submitScore,
    getLeaderboardEntries,
    requestAuth,
  };
})();
