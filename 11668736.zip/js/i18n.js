const I18N = {
  ru: {
    title: 'Кликер 67',
    points: 'Очки',
    perSec: '/ сек',
    clicks: 'Кликов',
    tapHint: 'Жми!',
    rewardBtn: '×2 на 30 сек (реклама)',
    saveBtn: 'Сохранить',
    tabUpgrades: 'Улучшения',
    tabAchievements: 'Достижения',
    tabLeaders: 'Лидеры',
    boostActive: 'Буст ×2!',
    loading: 'Загрузка...',
    saved: 'Сохранено',
    saveError: 'Ошибка сохранения',
    level: 'Ур.',
    lbLogin: 'Войти в Яндекс',
    lbEmpty: 'Пока нет результатов. Набирайте очки!',
    lbLocalOnly: 'Таблица лидеров доступна в Яндекс Играх.',
    lbNeedAuth: 'Войдите, чтобы попасть в таблицу лидеров.',
    lbLoading: 'Загрузка таблицы...',
    lbYou: 'Вы',
    lbAnon: 'Аноним',
    upgrade_finger: 'Палец 67',
    upgrade_finger_desc: '+1 за клик',
    upgrade_glove: 'Перчатка',
    upgrade_glove_desc: '+3 за клик',
    upgrade_brain: 'Мозг 67',
    upgrade_brain_desc: '+8 за клик',
    upgrade_bot: 'Бот-кликер',
    upgrade_bot_desc: '+2 / сек',
    upgrade_factory: 'Фабрика 67',
    upgrade_factory_desc: '+12 / сек',
    upgrade_mult: 'Множитель',
    upgrade_mult_desc: '×1.5 ко всему',
    ach_first: 'Первый 67',
    ach_first_desc: 'Сделай первый клик',
    ach_100: 'Сотня',
    ach_100_desc: '100 кликов',
    ach_1k: 'Тысячник',
    ach_1k_desc: '1 000 очков',
    ach_67k: 'Легенда 67',
    ach_67k_desc: '67 000 очков',
    ach_1m: 'Миллионер',
    ach_1m_desc: '1 000 000 очков',
    ach_max: 'Абсолютный 67',
    ach_max_desc: 'Купи все улучшения по 50 раз',
  },
  en: {
    title: 'Clicker 67',
    points: 'Points',
    perSec: '/ sec',
    clicks: 'Clicks',
    tapHint: 'Tap!',
    rewardBtn: '×2 for 30s (ad)',
    saveBtn: 'Save',
    tabUpgrades: 'Upgrades',
    tabAchievements: 'Achievements',
    tabLeaders: 'Leaders',
    boostActive: 'Boost ×2!',
    loading: 'Loading...',
    saved: 'Saved',
    saveError: 'Save failed',
    level: 'Lv.',
    lbLogin: 'Log in to Yandex',
    lbEmpty: 'No scores yet. Start earning points!',
    lbLocalOnly: 'The leaderboard is available on Yandex Games.',
    lbNeedAuth: 'Log in to appear on the leaderboard.',
    lbLoading: 'Loading leaderboard...',
    lbYou: 'You',
    lbAnon: 'Anonymous',
    upgrade_finger: 'Finger 67',
    upgrade_finger_desc: '+1 per click',
    upgrade_glove: 'Glove',
    upgrade_glove_desc: '+3 per click',
    upgrade_brain: 'Brain 67',
    upgrade_brain_desc: '+8 per click',
    upgrade_bot: 'Click bot',
    upgrade_bot_desc: '+2 / sec',
    upgrade_factory: 'Factory 67',
    upgrade_factory_desc: '+12 / sec',
    upgrade_mult: 'Multiplier',
    upgrade_mult_desc: '×1.5 to all',
    ach_first: 'First 67',
    ach_first_desc: 'Make your first click',
    ach_100: 'Hundred',
    ach_100_desc: '100 clicks',
    ach_1k: 'Thousand',
    ach_1k_desc: '1,000 points',
    ach_67k: '67 Legend',
    ach_67k_desc: '67,000 points',
    ach_1m: 'Millionaire',
    ach_1m_desc: '1,000,000 points',
    ach_max: 'Absolute 67',
    ach_max_desc: 'Buy every upgrade 50 times',
  },
};

let currentLang = 'ru';

function detectLang(ysdkLang) {
  const code = (ysdkLang || navigator.language || 'ru').slice(0, 2).toLowerCase();
  return I18N[code] ? code : 'ru';
}

function t(key) {
  const pack = I18N[currentLang] || I18N.ru;
  return pack[key] ?? I18N.ru[key] ?? key;
}

function applyI18n() {
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (key) el.textContent = t(key);
  });
  document.documentElement.lang = currentLang;
}

function setLanguage(lang) {
  currentLang = detectLang(lang);
  applyI18n();
}
